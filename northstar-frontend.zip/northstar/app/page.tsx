"use client";

import { useState, useMemo } from "react";
import { books, categories, getFeaturedBooks, getTrendingBooks, Category } from "@/data/books";
import { Sidebar } from "@/components/Sidebar";
import { TopNav } from "@/components/TopNav";
import { ResourceCard } from "@/components/ResourceCard";
import { SectionRow } from "@/components/SectionRow";
import { HeroBanner } from "@/components/HeroBanner";
import { BookOpen, Flame, Sparkles } from "lucide-react";

const categoryAccents: Record<string, string> = {
  "Product Management": "#9B8FFF",
  Startups: "#F5C842",
  Management: "#50C878",
};

export default function HomePage() {
  const [activeNav, setActiveNav] = useState("home");
  const [activeFilter, setActiveFilter] = useState<"All" | Category>("All");
  const [searchQuery, setSearchQuery] = useState("");

  const featured = getFeaturedBooks();
  const trending = getTrendingBooks();

  const filteredBooks = useMemo(() => {
    let result = books;
    if (activeFilter !== "All") {
      result = result.filter((b) => b.category === activeFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q) ||
          b.tags.some((t) => t.toLowerCase().includes(q)) ||
          b.description.toLowerCase().includes(q)
      );
    }
    return result;
  }, [activeFilter, searchQuery]);

  const heroBok = featured[0];

  const isFiltered = activeFilter !== "All" || searchQuery.trim() !== "";

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "var(--north-bg)" }}>
      {/* Sidebar */}
      <Sidebar activeNav={activeNav} onNavChange={setActiveNav} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Nav */}
        <TopNav
          activeFilter={activeFilter}
          onFilterChange={setActiveFilter}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />

        {/* Scrollable Content */}
        <main className="flex-1 overflow-y-auto scroll-container">
          {!isFiltered ? (
            // ── Default Home View ────────────────────────────────────────────
            <div className="pb-12">
              {/* Hero */}
              {heroBok && <HeroBanner book={heroBok} />}

              {/* Stats Strip */}
              <div className="flex gap-4 mx-6 mt-4 mb-6">
                {[
                  { label: "Total Books", value: "30", icon: BookOpen, color: "var(--north-accent)" },
                  { label: "Trending Now", value: trending.length.toString(), icon: Flame, color: "#F5C842" },
                  { label: "Categories", value: "3", icon: Sparkles, color: "#50C878" },
                ].map(({ label, value, icon: Icon, color }) => (
                  <div
                    key={label}
                    className="flex-1 flex items-center gap-3 p-3 rounded-xl"
                    style={{ background: "var(--north-card)", border: "1px solid var(--north-border)" }}
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: `${color}18` }}
                    >
                      <Icon size={16} style={{ color }} />
                    </div>
                    <div>
                      <div className="text-lg font-display font-bold" style={{ color: "var(--north-text)" }}>{value}</div>
                      <div className="text-xs" style={{ color: "var(--north-muted)" }}>{label}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Trending Row */}
              <SectionRow
                title="Trending"
                subtitle="Most popular this week"
                accentColor="#F5C842"
              >
                {trending.map((book) => (
                  <div key={book.id} style={{ scrollSnapAlign: "start" }}>
                    <ResourceCard book={book} variant="default" />
                  </div>
                ))}
              </SectionRow>

              {/* Latest Featured Row */}
              <div className="mt-8">
                <SectionRow
                  title="Latest Picks"
                  subtitle="Hand-curated for product leaders"
                  accentColor="var(--north-accent)"
                >
                  {featured.map((book) => (
                    <div key={book.id} style={{ scrollSnapAlign: "start" }}>
                      <ResourceCard book={book} variant="featured" />
                    </div>
                  ))}
                </SectionRow>
              </div>

              {/* Category Sections */}
              {categories.map((cat, idx) => {
                const catBooks = books.filter((b) => b.category === cat);
                return (
                  <div key={cat} className="mt-8">
                    <SectionRow
                      title={cat}
                      subtitle={`${catBooks.length} essential books`}
                      accentColor={categoryAccents[cat]}
                    >
                      {catBooks.map((book) => (
                        <div key={book.id} style={{ scrollSnapAlign: "start" }}>
                          <ResourceCard book={book} variant="default" />
                        </div>
                      ))}
                    </SectionRow>
                  </div>
                );
              })}

              {/* Case Studies Section */}
              <div className="mt-8 px-6 mb-8">
                <div className="flex items-center gap-2 mb-5">
                  <div className="w-1 h-5 rounded-full" style={{ background: "#50C878" }} />
                  <h2 className="font-display text-lg font-semibold" style={{ color: "var(--north-text)" }}>
                    Deep Dives & Case Studies
                  </h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {books
                    .filter((b) => b.featured)
                    .map((book) => (
                      <ResourceCard key={book.id} book={book} variant="case-study" />
                    ))}
                </div>
              </div>
            </div>
          ) : (
            // ── Filtered / Search View ───────────────────────────────────────
            <div className="p-6 pb-12">
              <div className="mb-6">
                <h2 className="font-display text-xl font-bold" style={{ color: "var(--north-text)" }}>
                  {searchQuery
                    ? `Results for "${searchQuery}"`
                    : activeFilter}
                </h2>
                <p className="text-sm mt-1" style={{ color: "var(--north-muted)" }}>
                  {filteredBooks.length} book{filteredBooks.length !== 1 ? "s" : ""} found
                </p>
              </div>

              {filteredBooks.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <BookOpen size={48} style={{ color: "var(--north-muted)", opacity: 0.4 }} />
                  <p className="text-lg font-display mt-4" style={{ color: "var(--north-muted)" }}>
                    No books found
                  </p>
                  <p className="text-sm mt-1" style={{ color: "var(--north-muted)", opacity: 0.6 }}>
                    Try a different search or category
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {filteredBooks.map((book) => (
                    <ResourceCard key={book.id} book={book} variant="list" />
                  ))}
                </div>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
