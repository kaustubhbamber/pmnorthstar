"use client";

import { Book } from "@/data/books";
import { ExternalLink, Star, BookOpen, TrendingUp } from "lucide-react";
import Image from "next/image";

interface HeroBannerProps {
  book: Book;
}

export function HeroBanner({ book }: HeroBannerProps) {
  return (
    <div
      className="relative mx-6 mt-6 rounded-2xl overflow-hidden cursor-pointer group"
      style={{ minHeight: "220px" }}
      onClick={() => window.open(book.link, "_blank", "noopener,noreferrer")}
    >
      {/* Background */}
      <div className="absolute inset-0 hero-gradient" />
      <div
        className="absolute inset-0"
        style={{
          background: "linear-gradient(135deg, #0A0A0F 0%, rgba(108,99,255,0.08) 40%, rgba(10,10,15,0.95) 100%)",
          border: "1px solid var(--north-border)",
          borderRadius: "inherit",
        }}
      />

      {/* Decorative book cover on right */}
      <div className="absolute right-0 top-0 bottom-0 w-64 overflow-hidden opacity-20 group-hover:opacity-30 transition-opacity">
        <Image
          src={book.thumbnailURL}
          alt={book.title}
          fill
          className="object-cover object-left scale-110 blur-sm"
          unoptimized
        />
      </div>
      <div className="absolute right-6 top-1/2 -translate-y-1/2 w-24 h-32 rounded-xl overflow-hidden shadow-2xl glow-accent transform group-hover:-translate-y-1/2 group-hover:scale-105 transition-transform duration-300">
        <Image
          src={book.thumbnailURL}
          alt={book.title}
          fill
          className="object-cover"
          unoptimized
        />
      </div>

      {/* Content */}
      <div className="relative z-10 p-8 pr-40">
        <div className="flex items-center gap-2 mb-3">
          <div
            className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full font-medium"
            style={{ background: "rgba(108,99,255,0.2)", color: "#9B8FFF", border: "1px solid rgba(108,99,255,0.3)" }}
          >
            <TrendingUp size={11} />
            Editor's Pick
          </div>
          <div
            className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full font-medium"
            style={{ background: "rgba(245,200,66,0.15)", color: "#F5C842", border: "1px solid rgba(245,200,66,0.3)" }}
          >
            <Star size={11} className="fill-current" />
            {book.rating.toFixed(1)}
          </div>
        </div>
        <h1 className="font-display text-3xl font-bold leading-tight mb-1" style={{ color: "var(--north-text)" }}>
          {book.title}
        </h1>
        <p className="text-sm mb-3" style={{ color: "var(--north-muted)" }}>
          by {book.author} · {book.year} · {book.pages} pages
        </p>
        <p className="text-sm max-w-md leading-relaxed mb-6" style={{ color: "var(--north-text)", opacity: 0.75 }}>
          {book.description}
        </p>
        <div className="flex items-center gap-3">
          <button
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white transition-all group-hover:scale-105"
            style={{ background: "var(--north-accent)" }}
          >
            <ExternalLink size={14} />
            Open Resource
          </button>
          <button
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all"
            style={{
              background: "var(--north-card)",
              border: "1px solid var(--north-border)",
              color: "var(--north-muted)",
            }}
          >
            <BookOpen size={14} />
            Save to Library
          </button>
        </div>
      </div>
    </div>
  );
}
