"use client";

import { Book } from "@/data/books";
import { ExternalLink, Star, BookOpen } from "lucide-react";
import Image from "next/image";

interface ResourceCardProps {
  book: Book;
  variant?: "default" | "featured" | "list" | "case-study";
}

const categoryBadgeClass: Record<string, string> = {
  "Product Management": "badge-pm",
  Startups: "badge-startups",
  Management: "badge-management",
};

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          size={10}
          className={i <= Math.round(rating) ? "star fill-current" : "text-north-muted"}
        />
      ))}
      <span className="text-xs text-north-text-muted ml-1 font-mono">{rating.toFixed(1)}</span>
    </div>
  );
}

export function ResourceCard({ book, variant = "default" }: ResourceCardProps) {
  const handleClick = () => {
    window.open(book.link, "_blank", "noopener,noreferrer");
  };

  if (variant === "featured") {
    return (
      <div
        onClick={handleClick}
        className="book-card relative flex-shrink-0 w-72 rounded-2xl overflow-hidden cursor-pointer group"
        style={{ background: "var(--north-card)", border: "1px solid var(--north-border)" }}
      >
        <div className="relative h-40 overflow-hidden">
          <Image
            src={book.thumbnailURL}
            alt={book.title}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-500"
            unoptimized
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#16161F] via-transparent to-transparent" />
          <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-sm rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
            <ExternalLink size={12} className="text-white" />
          </div>
          <span className={`absolute top-3 left-3 text-xs px-2 py-0.5 rounded-full font-medium ${categoryBadgeClass[book.category]}`}>
            {book.category}
          </span>
        </div>
        <div className="p-4">
          <h3 className="font-display text-base font-semibold text-north-text leading-tight mb-1 line-clamp-2">{book.title}</h3>
          <p className="text-xs text-north-text-muted mb-2">{book.author}</p>
          <StarRating rating={book.rating} />
          <p className="text-xs text-north-text-muted mt-2 line-clamp-2 leading-relaxed">{book.description}</p>
          <div className="flex flex-wrap gap-1 mt-3">
            {book.tags.slice(0, 2).map((tag) => (
              <span key={tag} className="text-xs px-2 py-0.5 rounded-full bg-north-surface text-north-text-muted border border-north-border">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (variant === "list") {
    return (
      <div
        onClick={handleClick}
        className="book-card flex gap-3 p-3 rounded-xl cursor-pointer group"
        style={{ background: "var(--north-card)", border: "1px solid var(--north-border)" }}
      >
        <div className="relative w-12 h-16 flex-shrink-0 rounded-lg overflow-hidden">
          <Image
            src={book.thumbnailURL}
            alt={book.title}
            fill
            className="object-cover"
            unoptimized
          />
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="font-display text-sm font-semibold text-north-text line-clamp-1">{book.title}</h4>
          <p className="text-xs text-north-text-muted mt-0.5">{book.author}</p>
          <StarRating rating={book.rating} />
          <div className="flex items-center gap-2 mt-1">
            <span className={`text-xs px-1.5 py-0.5 rounded-full ${categoryBadgeClass[book.category]}`}>
              {book.category.split(" ")[0]}
            </span>
            <span className="text-xs text-north-text-muted">{book.pages}p · {book.year}</span>
          </div>
        </div>
        <div className="flex-shrink-0 flex items-start pt-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <ExternalLink size={14} className="text-north-accent" />
        </div>
      </div>
    );
  }

  if (variant === "case-study") {
    return (
      <div
        onClick={handleClick}
        className="book-card relative rounded-2xl p-5 cursor-pointer group"
        style={{
          background: "linear-gradient(135deg, var(--north-card) 0%, rgba(108,99,255,0.05) 100%)",
          border: "1px solid var(--north-border)",
        }}
      >
        <div className="flex items-start gap-4">
          <div className="relative w-16 h-20 flex-shrink-0 rounded-xl overflow-hidden glow-accent">
            <Image
              src={book.thumbnailURL}
              alt={book.title}
              fill
              className="object-cover"
              unoptimized
            />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${categoryBadgeClass[book.category]}`}>
                Case Study
              </span>
              <ExternalLink size={13} className="text-north-accent opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <h3 className="font-display text-base font-semibold text-north-text mt-2 leading-tight">{book.title}</h3>
            <p className="text-xs text-north-text-muted mt-0.5">{book.author} · {book.year}</p>
            <StarRating rating={book.rating} />
          </div>
        </div>
        <p className="text-xs text-north-text-muted mt-3 leading-relaxed line-clamp-2">{book.description}</p>
        <div className="flex items-center gap-2 mt-3 pt-3" style={{ borderTop: "1px solid var(--north-border)" }}>
          <BookOpen size={12} className="text-north-accent" />
          <span className="text-xs text-north-text-muted">{book.pages} pages</span>
          <div className="flex gap-1 ml-auto">
            {book.tags.map((tag) => (
              <span key={tag} className="text-xs px-1.5 py-0.5 rounded bg-north-surface text-north-text-muted">
                #{tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Default card
  return (
    <div
      onClick={handleClick}
      className="book-card relative flex-shrink-0 w-44 rounded-xl overflow-hidden cursor-pointer group"
      style={{ background: "var(--north-card)", border: "1px solid var(--north-border)" }}
    >
      <div className="relative h-56 overflow-hidden">
        <Image
          src={book.thumbnailURL}
          alt={book.title}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-500"
          unoptimized
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#16161F] via-transparent to-transparent opacity-60" />
        <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
          <ExternalLink size={11} className="text-white" />
        </div>
        {book.trending && (
          <div className="absolute top-2 left-2 bg-north-gold/90 text-black text-xs px-1.5 py-0.5 rounded font-semibold">
            HOT
          </div>
        )}
      </div>
      <div className="p-3">
        <h3 className="font-display text-sm font-semibold text-north-text leading-tight line-clamp-2">{book.title}</h3>
        <p className="text-xs text-north-text-muted mt-1 truncate">{book.author}</p>
        <StarRating rating={book.rating} />
      </div>
    </div>
  );
}
