"use client";

import { Home, Library, Compass, TrendingUp, BookMarked, Star, Settings, ChevronRight } from "lucide-react";

interface SidebarProps {
  activeNav: string;
  onNavChange: (nav: string) => void;
}

const navItems = [
  { id: "home", label: "Home", icon: Home },
  { id: "library", label: "Library", icon: Library },
  { id: "explore", label: "Explore", icon: Compass },
  { id: "trending", label: "Trending", icon: TrendingUp },
];

const libraryItems = [
  { id: "saved", label: "Saved Books", icon: BookMarked },
  { id: "favorites", label: "Favorites", icon: Star },
];

export function Sidebar({ activeNav, onNavChange }: SidebarProps) {
  return (
    <aside
      className="flex flex-col h-full w-56 flex-shrink-0 py-6 px-3"
      style={{ background: "var(--north-surface)", borderRight: "1px solid var(--north-border)" }}
    >
      {/* Logo */}
      <div className="px-3 mb-8">
        <div className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, var(--north-accent), #9B8FFF)" }}
          >
            <Star size={16} className="text-white fill-white" />
          </div>
          <div>
            <span className="font-display text-lg font-bold tracking-tight" style={{ color: "var(--north-text)" }}>
              North
            </span>
            <span className="font-display text-lg font-bold tracking-tight" style={{ color: "var(--north-accent)" }}>
              Star
            </span>
          </div>
        </div>
        <p className="text-xs mt-1 px-0.5" style={{ color: "var(--north-muted)" }}>
          PM Resource Hub
        </p>
      </div>

      {/* Main Nav */}
      <nav className="flex-1 space-y-1">
        <p className="text-xs font-medium uppercase tracking-widest px-3 mb-2" style={{ color: "var(--north-muted)" }}>
          Navigate
        </p>
        {navItems.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => onNavChange(id)}
            className={`nav-item w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeNav === id ? "active" : ""
            }`}
            style={{
              color: activeNav === id ? "var(--north-accent)" : "var(--north-muted)",
              borderLeft: activeNav === id ? "2px solid var(--north-accent)" : "2px solid transparent",
            }}
          >
            <Icon size={16} />
            {label}
          </button>
        ))}

        <div className="pt-4">
          <p className="text-xs font-medium uppercase tracking-widest px-3 mb-2" style={{ color: "var(--north-muted)" }}>
            Library
          </p>
          {libraryItems.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => onNavChange(id)}
              className={`nav-item w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${
                activeNav === id ? "active" : ""
              }`}
              style={{
                color: activeNav === id ? "var(--north-accent)" : "var(--north-muted)",
                borderLeft: activeNav === id ? "2px solid var(--north-accent)" : "2px solid transparent",
              }}
            >
              <Icon size={16} />
              {label}
            </button>
          ))}
        </div>
      </nav>

      {/* Categories Quick Links */}
      <div className="mt-auto pt-4" style={{ borderTop: "1px solid var(--north-border)" }}>
        <p className="text-xs font-medium uppercase tracking-widest px-3 mb-2" style={{ color: "var(--north-muted)" }}>
          Categories
        </p>
        {[
          { label: "Product Management", color: "#9B8FFF" },
          { label: "Startups", color: "#F5C842" },
          { label: "Management", color: "#50C878" },
        ].map(({ label, color }) => (
          <div
            key={label}
            className="flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer group"
            style={{ transition: "background 0.2s" }}
            onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(108,99,255,0.06)")}
            onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
          >
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full" style={{ background: color }} />
              <span className="text-xs" style={{ color: "var(--north-muted)" }}>{label.split(" ")[0]}</span>
            </div>
            <ChevronRight size={12} style={{ color: "var(--north-muted)" }} className="opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        ))}
      </div>

      {/* Settings */}
      <button
        className="mt-3 flex items-center gap-3 px-3 py-2 rounded-lg text-sm w-full"
        style={{ color: "var(--north-muted)", transition: "color 0.2s" }}
        onMouseEnter={(e) => (e.currentTarget.style.color = "var(--north-text)")}
        onMouseLeave={(e) => (e.currentTarget.style.color = "var(--north-muted)")}
      >
        <Settings size={15} />
        Settings
      </button>
    </aside>
  );
}
