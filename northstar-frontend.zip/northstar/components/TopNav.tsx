"use client";

import { Search, Bell, User, X } from "lucide-react";
import { useState } from "react";
import { Category } from "@/data/books";

interface TopNavProps {
  activeFilter: "All" | Category;
  onFilterChange: (filter: "All" | Category) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

const filters: ("All" | Category)[] = ["All", "Product Management", "Startups", "Management"];

export function TopNav({ activeFilter, onFilterChange, searchQuery, onSearchChange }: TopNavProps) {
  const [focused, setFocused] = useState(false);

  return (
    <header
      className="flex-shrink-0 px-6 py-4 flex items-center gap-6"
      style={{
        background: "rgba(17, 17, 24, 0.85)",
        backdropFilter: "blur(16px)",
        borderBottom: "1px solid var(--north-border)",
        position: "sticky",
        top: 0,
        zIndex: 100,
      }}
    >
      {/* Search Bar */}
      <div
        className="flex items-center gap-2 flex-1 max-w-sm px-3 py-2 rounded-xl transition-all duration-200"
        style={{
          background: "var(--north-card)",
          border: `1px solid ${focused ? "var(--north-accent)" : "var(--north-border)"}`,
          boxShadow: focused ? "0 0 0 3px rgba(108, 99, 255, 0.12)" : "none",
        }}
      >
        <Search size={15} style={{ color: "var(--north-muted)", flexShrink: 0 }} />
        <input
          type="text"
          placeholder="Search books, authors..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          className="flex-1 bg-transparent text-sm outline-none"
          style={{ color: "var(--north-text)" }}
        />
        {searchQuery && (
          <button onClick={() => onSearchChange("")}>
            <X size={13} style={{ color: "var(--north-muted)" }} />
          </button>
        )}
      </div>

      {/* Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto scroll-container pb-0.5">
        {filters.map((filter) => (
          <button
            key={filter}
            onClick={() => onFilterChange(filter)}
            className={`filter-chip flex-shrink-0 text-xs px-3 py-1.5 rounded-full font-medium transition-all ${
              activeFilter === filter ? "active" : ""
            }`}
            style={{
              color: activeFilter === filter ? "white" : "var(--north-muted)",
              background: activeFilter === filter ? "var(--north-accent)" : "var(--north-card)",
              borderColor: activeFilter === filter ? "var(--north-accent)" : "var(--north-border)",
            }}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-3 ml-auto flex-shrink-0">
        <button
          className="relative p-2 rounded-lg transition-colors"
          style={{ background: "var(--north-card)", border: "1px solid var(--north-border)" }}
        >
          <Bell size={16} style={{ color: "var(--north-muted)" }} />
          <span
            className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full"
            style={{ background: "var(--north-accent)" }}
          />
        </button>
        <div
          className="w-8 h-8 rounded-full flex items-center justify-center cursor-pointer"
          style={{
            background: "linear-gradient(135deg, var(--north-accent), #9B8FFF)",
          }}
        >
          <User size={15} className="text-white" />
        </div>
      </div>
    </header>
  );
}
